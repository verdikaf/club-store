<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>ClubStore.com</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="assets/image/supermarket.png">
	<!-- Web Font -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="{{url('/assets/library/fontawesome/css/all.min.css')}}">
	
	<!-- StyleSheet -->
	
	<!-- Bootstrap -->
	<link rel="stylesheet" href="{{url('/assets/usertemplate/css/bootstrap.css')}}">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/magnific-popup.min.css')}}">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/font-awesome.css')}}">
	<!-- Fancybox -->
	<link rel="stylesheet" href="{{url('/assets/usertemplate/css/jquery.fancybox.min.css')}}">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/themify-icons.css')}}">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/niceselect.css')}}">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/animate.css')}}">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/flex-slider.min.css')}}">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/owl-carousel.css')}}">
	<!-- Slicknav -->
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/slicknav.min.css')}}">
	
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="{{url('/assets/usertemplate/css/reset.css')}}">
	<link rel="stylesheet" href="{{url('/assets/usertemplate/style.css')}}">
    <link rel="stylesheet" href="{{url('/assets/usertemplate/css/responsive.css')}}">

	<!-- EXTRAS CSS -->
	<link rel="stylesheet" href="{{url('/assets/css/dashboard-extras.css')}}">

	
	
</head>
<body class="js" id="wrapper">

@include('headerhome')
	
			<!-- Breadcrumbs -->
			<div class="breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="bread-inner">
							<ul class="bread-list">
								<li><a href="{{url('/')}}">Home<i class="ti-arrow-right"></i></a></li>
								<li class="active"><a href="blog-single.html">Profil</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->

		<!-- Start Profil -->
		<section class="shop checkout section">
			<div class="container">
				<div class="row"> 
					<div class="col-lg-8 col-12">
						<div class="checkout-form">
							<h2>Edit Profilmu Disini</h2>
                            <p>Mohon edit data dengan benar untuk membantu pengiriman</p>
							<!-- Form -->
                            <form class="form" action="{{url('/profil/edit')}}" method="post">
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                            <input type="hidden" name="id" value="{{$user->id}}" class="form-control" placeholder="tulis id disini">
								
							</div>

							<form  class="form">
								<div class="row">
									<div class="col-lg-12 col-md-6 col-12">
										<div class="form-group">
											<label>Name</label>
											<input type="text" value="{{$user->nama}}" name="nama" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
											<label>Kecamatan</label>
											<input type="text" name="kecamatan" value="{{$user->kecamatan}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
											<label>Kota</label>
											<input type="text" name="kota" value="{{$user->kota}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
											<label>Provinsi<span>*</span></label>
											<input type="text" name="provinsi" value="{{$user->provinsi}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
											<label>Kode Pos<span>*</span></label>
											<input type="text" name="kode_pos" value="{{$user->kode_pos}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-12 col-md-6 col-12">
										<div class="form-group">
											<label>Nomer Telepon</label>
											<input type="text" name="telp" value="{{$user->telp}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-12 col-md-6 col-12">
										<div class="form-group">
											<label>Alamat Lengkap</label>
											<input type="text" name="alamat_lengkap" value="{{$user->alamat_lengkap}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
											<label>Email</label>
											<input type="email" name="email" value="{{$user->email}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
											<label>Password</label>
											<input type="password" name="password" value="{{$user->password}}" placeholder="" required="required">
										</div>
									</div>
									<div class="col-12">
										<input type="submit" value="Submit" class="btn btn-primary" >
									</div>
								</div>
							</form>
							<!--/ End Form -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Checkout -->
    
    <!-- Start Footer Area -->
	<footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<h4>ClubStore.com</h4>
							</div>
							<p class="text">Praesent dapibus, neque id cursus ucibus, tortor neque egestas augue,  magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus.</p>
							<p class="call">Tanya? Call Us 24/7<span><a href="tel:123456789">+0123 456 789</a></span></p>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Informasi</h4>
							<ul>
								<li><a href="#">Tentang Kami</a></li>
								<li><a href="#">Faq</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Kontak Kami</a></li>
								<li><a href="#">Help</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-2 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer links">
							<h4>Customer Service</h4>
							<ul>
								<li><a href="#">Metode Pembayran</a></li>
								<li><a href="#">Money-back</a></li>
								<li><a href="#">Pengembalian</a></li>
								<li><a href="#">Pengantaran</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer social">
							<h4>Kunjungi Kami</h4>
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>NO. 342 - Veteran.</li>
									<li>012 Malang.</li>
									<li>info@clubstore.com</li>
									<li>+0123 456 789</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->
					</div>
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2020 <a href="http://www.wpthemesgrid.com" target="_blank">Wpthemesgrid</a>  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="{{url('/assets/usertemplate/images/Payments.png')}}" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->
    

 
	<!-- Jquery -->
    <script src="{{url('/assets/usertemplate/js/jquery.min.js')}}"></script>
    <script src="{{url('/assets/usertemplate/js/jquery-migrate-3.0.0.js')}}"></script>
	<script src="{{url('/assets/usertemplate/js/jquery-ui.min.js')}}"></script>
	<!-- Popper JS -->
	<script src="{{url('/assets/usertemplate/js/popper.min.js')}}"></script>
	<!-- Bootstrap JS -->
	<script src="{{url('/assets/usertemplate/js/bootstrap.min.js')}}"></script>
	<!-- Color JS -->
	<script src="{{url('/assets/usertemplate/js/colors.js')}}"></script>
	<!-- Slicknav JS -->
	<script src="{{url('/assets/usertemplate/js/slicknav.min.js')}}"></script>
	<!-- Owl Carousel JS -->
	<script src="{{url('/assets/usertemplate/js/owl-carousel.js')}}"></script>
	<!-- Magnific Popup JS -->
	<script src="{{url('/assets/usertemplate/js/magnific-popup.js')}}"></script>
	<!-- Waypoints JS -->
	<script src="{{url('/assets/usertemplate/js/waypoints.min.js')}}"></script>
	<!-- Countdown JS -->
	<script src="{{url('/assets/usertemplate/js/finalcountdown.min.js')}}"></script>
	<!-- Nice Select JS -->
	<script src="{{url('/assets/usertemplate/js/nicesellect.js')}}"></script>
	<!-- Flex Slider JS -->
	<script src="{{url('/assets/usertemplate/js/flex-slider.js')}}"></script>
	<!-- ScrollUp JS -->
	<script src="{{url('/assets/usertemplate/js/scrollup.js')}}"></script>
	<!-- Onepage Nav JS -->
	<script src="{{url('/assets/usertemplate/js/onepage-nav.min.js')}}"></script>
	<!-- Easing JS -->
	<script src="{{url('/assets/usertemplate/js/easing.js')}}"></script>
	<!-- Active JS -->
	<script src="{{url('/assets/usertemplate/js/active.js')}}"></script>

			<!-- Menu Toggle Script -->
			<script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
</body>
</html>